Data Access Layer         CategoryDao.java,CategoryDaoImpl.java               This file contains maethos to create and get all categories
Business Layer		CategoryBL.java,CategoryBLImpl.java			This file contains maethos to create and get all categories
exception		FileCreationexception.java				to get custome exception
entities		categories.java,fruitItem.java...			parent and inheretd classes