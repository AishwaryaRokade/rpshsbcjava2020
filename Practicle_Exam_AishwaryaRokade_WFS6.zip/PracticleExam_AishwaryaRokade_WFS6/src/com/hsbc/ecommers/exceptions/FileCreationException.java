package com.hsbc.ecommers.exceptions;

public class FileCreationException extends Exception{
	///IO exception 
	public FileCreationException(String message)
	{
		super(message);
	}

}
