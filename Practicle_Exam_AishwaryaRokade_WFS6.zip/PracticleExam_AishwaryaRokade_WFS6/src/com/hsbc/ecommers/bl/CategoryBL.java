//Author<Aishwary Achyutkumar Rokade>
//Purpose: interface of business layer
//

package com.hsbc.ecommers.bl;

import java.io.IOException;

import com.hsbc.ecommers.exceptions.FileCreationException;
import com.hsbc.ecommers.models.Categories;

public interface CategoryBL {
	
	//methods to add and display category
		boolean addCategory(Categories[] categrory) throws FileCreationException; 
		Categories[] getAllCategories() throws FileCreationException;

}
