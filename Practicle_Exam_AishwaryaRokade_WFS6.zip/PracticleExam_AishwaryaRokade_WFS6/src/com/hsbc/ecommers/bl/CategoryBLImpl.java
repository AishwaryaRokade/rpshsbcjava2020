//Author<Aishwary Achyutkumar Rokade>
//Purpose: Business layer implementation 
//

package com.hsbc.ecommers.bl;

import java.io.IOException;

import com.hsbc.ecommers.dao.CategoryDao;
import com.hsbc.ecommers.dao.CategoryDaoImpl;
import com.hsbc.ecommers.exceptions.FileCreationException;
import com.hsbc.ecommers.models.Categories;

public class CategoryBLImpl implements CategoryBL{

	private CategoryDao categoryDao;                               //connecting with the Dao layer
	
	public CategoryBLImpl() throws FileCreationException
	{
		try {
			categoryDao = new CategoryDaoImpl();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File not created...Check the Location ");
		}
	}
	@Override
	public boolean addCategory(Categories[] categrory) throws FileCreationException {                           //adding the categorys by taking from dao
		// TODO Auto-generated method stub
		try {
			return categoryDao.addCategory(categrory);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File not created...Check the Location ");
		}
	}

	@Override
	public Categories[] getAllCategories() throws FileCreationException {                                   //geting all categroies from dao layer
		// TODO Auto-generated method stub
		try {
			return categoryDao.getAllCategories();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File not created...Check the Location ");
		}
	}

}
