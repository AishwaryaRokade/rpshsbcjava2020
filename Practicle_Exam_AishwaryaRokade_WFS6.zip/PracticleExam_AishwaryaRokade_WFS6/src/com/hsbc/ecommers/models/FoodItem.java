//Author<Aishwary Achyutkumar Rokade>
//Purpose: Food Item which inheret category
//

package com.hsbc.ecommers.models;

import java.time.LocalDate;

public class FoodItem extends Categories{
	
	LocalDate dateOfManufacture; 
	LocalDate dateOfExpire;
	boolean vegetarian;
	public LocalDate getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(LocalDate dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public LocalDate getDateOfExpire() {
		return dateOfExpire;
	}
	public void setDateOfExpire(LocalDate dateOfExpire) {
		this.dateOfExpire = dateOfExpire;
	}
	public boolean isVegetarian() {
		return vegetarian;
	}
	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}
	@Override
	public String toString() {
		return super.toString() + "FoodItem [dateOfManufacture=" + dateOfManufacture + ", dateOfExpire=" + dateOfExpire + ", vegetarian="
				+ vegetarian + "]";
	}
	

}
