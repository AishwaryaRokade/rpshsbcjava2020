//Author<Aishwary Achyutkumar Rokade>
//Purpose: Category class
//
package com.hsbc.ecommers.models;

import java.io.Serializable;

//categorie class contains all common methods in category
public class Categories implements Serializable {
	
	private String itemCode;                    //code of item
	private String itemName;                    //Name of Item
	private int unitPrice;                      //price pre unit of item
	private int quantity;                      //quantity of iten
	
	//setters and getters methods
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Categories [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", quantity=" + quantity + "]";
	}
	

}
