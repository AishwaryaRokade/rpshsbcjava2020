//Author<Aishwary Achyutkumar Rokade>
//Purpose: Electronics class inherets category
//
package com.hsbc.ecommers.models;

public class Electronics extends Categories{

	private int warrentyInMonths;

	public int getWarrentyInMonths() {
		return warrentyInMonths;
	}

	public void setWarrentyInMonths(int warrentyInMonths) {
		this.warrentyInMonths = warrentyInMonths;
	}

	@Override
	public String toString() {
		return super.toString() + "Electronics [warrentyInMonths=" + warrentyInMonths + "]";
	}
	
	
}
