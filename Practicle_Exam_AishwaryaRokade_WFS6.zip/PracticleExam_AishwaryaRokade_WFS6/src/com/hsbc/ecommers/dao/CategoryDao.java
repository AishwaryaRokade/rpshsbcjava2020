//Author<Aishwary Achyutkumar Rokade>
//Purpose: Creates a doa layer and all methods
//
package com.hsbc.ecommers.dao;

import java.io.IOException;

import com.hsbc.ecommers.models.Categories;

//Interface for data layer
public interface CategoryDao {

	//methods to add and display category
	boolean addCategory(Categories[] categrory) throws IOException;
	Categories[] getAllCategories() throws ClassNotFoundException, IOException;
}
