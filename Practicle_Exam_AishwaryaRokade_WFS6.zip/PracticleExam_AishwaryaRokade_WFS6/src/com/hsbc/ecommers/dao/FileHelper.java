//Author<Aishwary Achyutkumar Rokade>
//Purpose: Helper Class to create file
//
package com.hsbc.ecommers.dao;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
public class FileHelper {
	//Class to create a file
	private static File file;
	private static ResourceBundle resourceBundle;
	
	public static File createFile() throws IOException
	{
		
		resourceBundle = ResourceBundle.getBundle("com/hsbc/ecommers/resources/ecomerce");                          // location to insurance.properties
		//create file
		
		file=new File(resourceBundle.getString("filename"));
		if(!file.exists())
			file.createNewFile();
		
		
        return file; 	
		
		
	}

}

