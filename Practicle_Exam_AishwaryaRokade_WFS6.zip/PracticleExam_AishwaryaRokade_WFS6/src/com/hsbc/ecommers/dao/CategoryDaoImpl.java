//Author<Aishwary Achyutkumar Rokade>
//Purpose: Creates a doa layer and all methods
//

package com.hsbc.ecommers.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.hsbc.ecommers.models.Categories;

//implementing data layer interface
public class CategoryDaoImpl implements CategoryDao{

	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;

	public CategoryDaoImpl() throws IOException
	{
		file = FileHelper.createFile();                               // creating a file
	}
	@Override
	public boolean addCategory(Categories[] categrory) throws IOException {                       //adding data to categories
		// TODO Auto-generated method stub
		boolean status=false;
		fileOutputStream = new FileOutputStream(file, true);                       // append mode
		objectOutputStream = new ObjectOutputStream(fileOutputStream);
		for(int i =0;i<categrory.length;i++)
		{
			objectOutputStream.writeObject(categrory[i]);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		status = true;
		return status;
	}

	public int getObjectCount() throws IOException, ClassNotFoundException                       //geting count of no of items  
	{
		fileInputStream = new FileInputStream(file);
		objectInputStream = new ObjectInputStream(fileInputStream);
		Categories category = null;
		int count = 0;
		while(objectInputStream.readObject()!=null)
		{
			count++;
		}
		return count;

	}
	@Override
	public Categories[] getAllCategories() throws ClassNotFoundException, IOException {                     //displaying items
		// TODO Auto-generated method stub
		int count = getObjectCount();
		Categories[] categories = new Categories[count];
		int pos = 0;
		fileInputStream = new FileInputStream(file);
		objectInputStream = new ObjectInputStream(fileInputStream);
		Categories category = null;
		
		while((category = (Categories)objectInputStream.readObject())!= null)
		{
			categories[pos] = category;
			pos++;
		}
		return null;
	}

}
