//Author<Aishwary Achyutkumar Rokade>
//Purpose: Accepting and displaying of data
//

package com.hsbc.ecommers.views;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.hsbc.ecommers.bl.CategoryBL;
import com.hsbc.ecommers.bl.CategoryBLImpl;
import com.hsbc.ecommers.exceptions.FileCreationException;
import com.hsbc.ecommers.models.Categories;
import com.hsbc.ecommers.models.FoodItem;

public class CategoryApp {
	private static CategoryBL categoryBL;                             //connecting with bussiness layer
	static
	{
		try {
			categoryBL = new CategoryBLImpl();
		} catch (FileCreationException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());;
		}
	}
	private static void addCategories()                    //Add category
	{
		FoodItem[] categories =  new FoodItem[5];
		for(int i =0;i<categories.length;i++)
		{
			categories[i] = new FoodItem();
			categories[i].setItemCode("FI"+ new Random().nextInt(100));
			//categories[i].setItemName(itemName);
			categories[i].setQuantity(new Random().nextInt(100));
			categories[i].setUnitPrice(5);
			categories[i].setDateOfExpire(LocalDate.of(2020, 3, 31));
			categories[i].setDateOfExpire(LocalDate.of(2020, 3, 31));
			categories[i].setVegetarian(true);
			
		}
		try {
			categoryBL.addCategory(categories);
		} catch (FileCreationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void getAllCategories()                            //display category
	{
		List<Categories> categ = new ArrayList<Categories>();
		int count=0;
		try {
			for(Categories categories : categoryBL.getAllCategories())                      //sorting category based on quantity
			{
				for(Categories category : categoryBL.getAllCategories())
				{
					if(categories.getQuantity()>category.getQuantity())
					{
						categ.add(categories);
					}
						
				}
				
			}
		} catch (FileCreationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void choice()
	{
		int option =0;
		switch(option)
		{
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		default:
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addCategories();
		

	}

}
